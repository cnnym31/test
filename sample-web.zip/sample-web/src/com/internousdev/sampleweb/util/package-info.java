/**
 * 
 */
/**
 * @author inouetakuma
 *
 */
package com.internousdev.sampleweb.util;