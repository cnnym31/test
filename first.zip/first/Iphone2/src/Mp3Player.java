
public class Mp3Player {

	public void play(){
		System.out.println("再生");
	}

	public void stop(){
		System.out.println("停止");
	}

	public void next(){
		System.out.println("次へ");
	}

	public void back(){
		System.out.println("戻る");
	}


}
