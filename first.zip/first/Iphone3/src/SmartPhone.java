
public class SmartPhone extends Phone implements Mp3Player, NewFunction {





}
