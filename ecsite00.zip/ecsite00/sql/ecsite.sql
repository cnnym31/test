set names utf8;
set foreign_key_checks = 0;
drop database if exists ecsite;

create database if not exists ecsite;
use ecsite;

/* ユーザ情報テーブル */
drop table if exists login_user_transaction;

create table login_user_transaction(
	id int not null primary key auto_increment,
	login_id varchar(16) unique,
	login_pass varchar(16),
	user_name varchar(50),
	insert_date datetime
);

insert into login_user_transaction(login_id, login_pass, user_name, insert_date) values("admin", "admin", "管理者", now());
insert into login_user_transaction(login_id, login_pass, user_name, insert_date) values("guest", "guest", "ゲスト", now());
insert into login_user_transaction(login_id, login_pass, user_name, insert_date) values("taro", "123", "yamadataro", now());

/* 商品情報テーブル */
drop table if exists item_info_transaction;

create table item_info_transaction(
	id int not null primary key auto_increment,
	item_name varchar(30),
	item_price int,
	item_stock int,
	image_file_path varchar(100),
	image_file_name varchar(50),
	insert_date datetime,
	update_date datetime
);

insert into item_info_transaction(item_name, item_price, item_stock, image_file_path, image_file_name, insert_date) values("test01", 100, 50, "./images", "test.png", now());
insert into item_info_transaction(item_name, item_price, item_stock, image_file_path, image_file_name, insert_date) values("test02", 100, 50, "./images", "test.png", now());
insert into item_info_transaction(item_name, item_price, item_stock, image_file_path, image_file_name, insert_date) values("test03", 100, 50, "./images", "test.png", now());
insert into item_info_transaction(item_name, item_price, item_stock, image_file_path, image_file_name, insert_date) values("test04", 100, 50, "./images", "test.png", now());
insert into item_info_transaction(item_name, item_price, item_stock, image_file_path, image_file_name, insert_date) values("test05", 100, 50, "./images", "test.png", now());
insert into item_info_transaction(item_name, item_price, item_stock, image_file_path, image_file_name, insert_date) values("test06", 100, 50, "./images", "test.png", now());
insert into item_info_transaction(item_name, item_price, item_stock, image_file_path, image_file_name, insert_date) values("test07", 100, 50, "./images", "test.png", now());
insert into item_info_transaction(item_name, item_price, item_stock, image_file_path, image_file_name, insert_date) values("test08", 100, 50, "./images", "test.png", now());
insert into item_info_transaction(item_name, item_price, item_stock, image_file_path, image_file_name, insert_date) values("test09", 100, 50, "./images", "test.png", now());
insert into item_info_transaction(item_name, item_price, item_stock, image_file_path, image_file_name, insert_date) values("test10", 100, 50, "./images", "test.png", now());
insert into item_info_transaction(item_name, item_price, item_stock, image_file_path, image_file_name, insert_date) values("test11", 100, 50, "./images", "test.png", now());
insert into item_info_transaction(item_name, item_price, item_stock, image_file_path, image_file_name, insert_date) values("test12", 100, 50, "./images", "test.png", now());
insert into item_info_transaction(item_name, item_price, item_stock, image_file_path, image_file_name, insert_date) values("test13", 100, 50, "./images", "test.png", now());
insert into item_info_transaction(item_name, item_price, item_stock, image_file_path, image_file_name, insert_date) values("test14", 100, 50, "./images", "test.png", now());





/* カート情報テーブル */
drop table if exists cart_info;

create table cart_info(
	id int primary key not null auto_increment,
	user_id varchar(16),
	item_id int,
	item_count int,
	item_price int,
	insert_date datetime,
	update_date datetime
);


/* 購入履歴情報テーブル */
drop table if exists user_buy_item_transaction;

create table user_buy_item_transaction(
	id int not null primary key auto_increment,
	item_transaction_id int,
	total_price int,
	total_count int,
	user_master_id varchar(16),
	pay varchar(30),
	insert_date datetime,
	update_date datetime
);

/* 宛先情報テーブル */
drop table if exists destination_info;

create table destination_info(
	id int not null primary key auto_increment,
	user_id varchar(16),
	family_name varchar(32),
	first_name varchar(32),
	family_name_kana varchar(32),
	first_name_kana varchar(32),
	email varchar(32),
	tel_number varchar(13),
	user_address varchar(50),
	insert_date datetime,
	update_date datetime
);

insert into destination_info(user_id, family_name, first_name, family_name_kana, first_name_kana, email, tel_number, user_address, insert_date) VALUES("guest", "guest", "user", "ゲスト", "ユーザー", "guest@gmail.com", "123-456-7890", "東京都〇〇区", now());


