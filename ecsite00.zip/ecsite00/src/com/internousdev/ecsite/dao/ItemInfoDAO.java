package com.internousdev.ecsite.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.internousdev.ecsite.dto.ItemInfoDTO;
import com.internousdev.ecsite.util.DBConnector;
import com.internousdev.ecsite.util.DateUtil;

public class ItemInfoDAO {

	public List<ItemInfoDTO> getItemList() {
		List<ItemInfoDTO> itemList = new ArrayList<ItemInfoDTO>();
		DBConnector dbConnector = new DBConnector();
		Connection connection = dbConnector.getConnection();

		String sql = "SELECT * FROM item_info_transaction";

		try{
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			ResultSet resultSet = preparedStatement.executeQuery();

			while(resultSet.next()){
				ItemInfoDTO dto = new ItemInfoDTO();
				dto.setId(resultSet.getInt("id"));
				dto.setItemName(resultSet.getString("item_name"));
				dto.setItemPrice(resultSet.getInt("item_price"));
				dto.setItemStock(resultSet.getInt("item_stock"));
				dto.setImageFilePath(resultSet.getString("image_file_path"));
				dto.setImageFileName(resultSet.getString("image_file_name"));
				dto.setInsert_date(resultSet.getString("insert_date"));
				dto.setUpdate_date(resultSet.getString("update_date"));
				itemList.add(dto);
			}
		} catch (SQLException e){
			e.printStackTrace();
		}

		try {
			connection.close();
		} catch (SQLException e){
			e.printStackTrace();
		}

		return itemList;
	}

	public ItemInfoDTO getItemInfo(int id){
		DBConnector dbConnector = new DBConnector();
		Connection connection = dbConnector.getConnection();
		ItemInfoDTO itemListDTO = new ItemInfoDTO();

		String sql = "SELECT * FROM item_info_transaction WHERE id=?";

		try{
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();

			while(resultSet.next()){
				itemListDTO.setId(resultSet.getInt("id"));
				itemListDTO.setItemName(resultSet.getString("item_name"));
				itemListDTO.setItemPrice(resultSet.getInt("item_price"));
				itemListDTO.setItemStock(resultSet.getInt("item_stock"));
				itemListDTO.setImageFilePath(resultSet.getString("image_file_path"));
				itemListDTO.setImageFileName(resultSet.getString("image_file_name"));
				itemListDTO.setInsert_date(resultSet.getString("insert_date"));
				itemListDTO.setUpdate_date(resultSet.getString("update_date"));
			}
		} catch (SQLException e){
			e.printStackTrace();
		}

		try{
			connection.close();
		} catch (SQLException e){
			e.printStackTrace();
		}

		return itemListDTO;
	}

	public void itemCreate(String itemName, String itemPrice, String itemStock) {
		DBConnector dbConnector = new DBConnector();
		Connection connection = dbConnector.getConnection();
		DateUtil dateUtil = new DateUtil();

		String sql = "INSERT INTO item_info_transaction(item_name, item_price, item_stock, insert_date) VALUES(?, ?, ?, ?)";

		try {
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, itemName);
			preparedStatement.setString(2, itemPrice);
			preparedStatement.setString(3, itemStock);
			preparedStatement.setString(4, dateUtil.getDate());

			preparedStatement.execute();
		} catch (SQLException e){
			e.printStackTrace();
		}

		try {
			connection.close();
		} catch (SQLException e){
			e.printStackTrace();
		}
	}

	public int itemUpdate(String itemName, int itemPrice, int itemStock, int id) {
		DBConnector dbConnector = new DBConnector();
		Connection connection = dbConnector.getConnection();
		DateUtil dateUtil = new DateUtil();

		String sql = "UPDATE item_info_transaction SET item_name=?, item_price=?, item_stock=?, update_date=? WHERE id=?";

		int result = 0;

		try{
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, itemName);
			preparedStatement.setInt(2, itemPrice);
			preparedStatement.setInt(3, itemStock);
			preparedStatement.setString(4, dateUtil.getDate());
			preparedStatement.setInt(5, id);
			result = preparedStatement.executeUpdate();
		} catch (SQLException e){
			e.printStackTrace();
		}

		try {
			connection.close();
		} catch (SQLException e){
			e.printStackTrace();
		}

		return result;
	}

	public int itemDelete(int id) {
		DBConnector dbConnector = new DBConnector();
		Connection connection = dbConnector.getConnection();

		String sql = "DELETE FROM item_info_transaction WHERE id=?";

		int result = 0;

		try{
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1,id);
			result = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {
			connection.close();
		} catch (SQLException e){
			e.printStackTrace();
		}

		return result;
	}

	public int itemAllDelete() {
		DBConnector dbConnector = new DBConnector();
		Connection connection = dbConnector.getConnection();

		String sql = "DELETE FROM item_info_transaction";

		int result = 0;

		try{
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			result = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		try{
			connection.close();
		} catch (SQLException e){
			e.printStackTrace();
		}

		return result;
	}

}
