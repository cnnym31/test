package com.internousdev.ecsite.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.internousdev.ecsite.dto.CartInfoDTO;
import com.internousdev.ecsite.util.DBConnector;
import com.internousdev.ecsite.util.DateUtil;

public class CartInfoDAO {
	public int addCart(int userId, int itemId, int itemCount, int itemPrice){
		DBConnector dbConnector = new DBConnector();
		Connection connection = dbConnector.getConnection();
		DateUtil dateUtil = new DateUtil();

		int result = 0;

		String sql = "INSERT INTO cart_info(user_id, item_id, item_count, item_price, insert_date) VALUES(?, ?, ?, ?, ?)";

		try{
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, userId);
			preparedStatement.setInt(2, itemId);
			preparedStatement.setInt(3, itemCount);
			preparedStatement.setInt(4, itemPrice);
			preparedStatement.setString(5, dateUtil.getDate());
			result = preparedStatement.executeUpdate();
		} catch (Exception e){
			e.printStackTrace();
		}

		try {
			connection.close();
		} catch (SQLException e){
			e.printStackTrace();
		}

		return result;
	}

	public List<CartInfoDTO> getCartInfoDTOList(int userId){
		DBConnector dbConnector = new DBConnector();
		Connection connection = dbConnector.getConnection();
		List<CartInfoDTO> cartInfoDTOList = new ArrayList<CartInfoDTO>();

		String sql = "SELECT"
				+ " ci.id, ci.user_id, ci.item_id, ci.item_count,"
				+ " ci.insert_date, ci.update_date,"
				+ " iit.item_name, iit.item_price, iit.item_stock,"
				+ " iit.image_file_path, iit.image_file_name, (ci.item_count * iit.item_price) as total_price"
				+ " FROM cart_info ci LEFT JOIN item_info_transaction iit"
				+ " ON ci.item_id = iit.id"
				+ " WHERE ci.user_id=?"
				+ " group by item_id";

		try{
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, userId);
			ResultSet resultSet = preparedStatement.executeQuery();

			while(resultSet.next()){
				CartInfoDTO cartInfoDTO = new CartInfoDTO();
				cartInfoDTO.setId(resultSet.getInt("id"));
				cartInfoDTO.setUserId(resultSet.getString("user_id"));
				cartInfoDTO.setItemId(resultSet.getInt("item_id"));
				cartInfoDTO.setItemCount(resultSet.getInt("item_count"));
				cartInfoDTO.setItemPrice(resultSet.getInt("item_price"));
				cartInfoDTO.setInsert_date(resultSet.getString("insert_date"));
				cartInfoDTO.setUpdate_date(resultSet.getString("update_date"));
				cartInfoDTO.setItemName(resultSet.getString("item_name"));
				cartInfoDTO.setItemStock(resultSet.getInt("item_stock"));
				cartInfoDTO.setImageFilePath(resultSet.getString("image_file_path"));
				cartInfoDTO.setImageFileName(resultSet.getString("image_file_name"));
				cartInfoDTO.setTotalPrice(resultSet.getInt("total_price"));
				cartInfoDTOList.add(cartInfoDTO);
			}
		} catch (Exception e){
			e.printStackTrace();
		}

		try{
			connection.close();
		} catch(SQLException e){
			e.printStackTrace();
		}

		return cartInfoDTOList;

	}

	public int getTotalPrice(int userId){
		DBConnector dbConnector = new DBConnector();
		Connection connection = dbConnector.getConnection();

		int totalPrice = 0;

		String sql = "SELECT sum(item_count * item_price) as total_price"
				+ " FROM cart_info WHERE user_id=? group by user_id";

		try{
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, userId);
			ResultSet resultSet = preparedStatement.executeQuery();

			if(resultSet.next()){
				totalPrice = resultSet.getInt("total_price");
			}
		} catch (SQLException e){
			e.printStackTrace();
		}

		try {
			connection.close();
		} catch (SQLException e){
			e.printStackTrace();
		}

		return totalPrice;
	}

	public int delete(String id){
		DBConnector dbConnector = new DBConnector();
		Connection connection = dbConnector.getConnection();

		int count = 0;

		String sql = "DELETE from cart_info WHERE id=?";

		try{
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1,id);
			count = preparedStatement.executeUpdate();
		} catch (SQLException e){
			e.printStackTrace();
		}

		try {
			connection.close();
		} catch(SQLException e){
			e.printStackTrace();
		}

		return count;
	}


}
