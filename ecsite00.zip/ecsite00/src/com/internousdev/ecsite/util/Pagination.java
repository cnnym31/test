package com.internousdev.ecsite.util;

import java.util.ArrayList;
import java.util.List;

import com.internousdev.ecsite.dto.ItemInfoDTO;
import com.internousdev.ecsite.dto.PaginationDTO;

public class Pagination {

	public PaginationDTO initialize(List<ItemInfoDTO> list, int pageSize){

		PaginationDTO paginationDTO = new PaginationDTO();

		// 全ページ数
		paginationDTO.setTotalPageSize((int)(Math.ceil(list.size() / pageSize)));
		// 現在のページ番号
		paginationDTO.setCurrentPageNo(1);
		// 全レコード数
		paginationDTO.setTotalRecordSize(list.size() - 1);
		// 現在のページ番号に対する開始レコード番号（オフセット）
		paginationDTO.setStartRecordNo(pageSize * (paginationDTO.getCurrentPageNo() - 1));
		// 現在のページ番号に対する終了レコード番号
		paginationDTO.setEndRecordNo(paginationDTO.getStartRecordNo() + (pageSize - 1));

		List<Integer> pageNumberList = new ArrayList<Integer>();
		for(int pageNumber = 1; pageNumber <= paginationDTO.getTotalPageSize(); pageNumber++){
			pageNumberList.add(pageNumber);
		}

		List<ItemInfoDTO> productInfoPages = new ArrayList<ItemInfoDTO>();
		for(int pageNumberOffset = paginationDTO.getStartRecordNo(); pageNumberOffset <= paginationDTO.getEndRecordNo(); pageNumberOffset++){
			productInfoPages.add(list.get(pageNumberOffset));
		}
		paginationDTO.setCurrentProductInfoPage(productInfoPages);

		if((paginationDTO.getStartRecordNo() -1) <= 0){
			paginationDTO.setPreviousPage(false);
		} else {
			paginationDTO.setPreviousPage(true);
			paginationDTO.setPreviousPageNo(paginationDTO.getCurrentPageNo() - 1);
		}

		if(paginationDTO.getEndRecordNo() + pageSize > paginationDTO.getTotalRecordSize()){
			paginationDTO.setNextPage(false);
		} else {
			paginationDTO.setNextPage(true);
			paginationDTO.setNextPageNo(paginationDTO.getCurrentPageNo() + 1);
		}

		return paginationDTO;
	}

	public PaginationDTO getPage(List<ItemInfoDTO> list, int pageSize, String pageNo){

		PaginationDTO pagenationDTO = new PaginationDTO();

		// 全ページ数
		pagenationDTO.setTotalPageSize((int)(Math.ceil(list.size() / pageSize)));
		// 現在のページ番号
		pagenationDTO.setCurrentPageNo(1);
		// 全レコード数
		pagenationDTO.setTotalRecordSize(list.size() - 1);
		// 現在のページ番号に対する開始レコード番号（オフセット）
		pagenationDTO.setStartRecordNo(pageSize * (pagenationDTO.getCurrentPageNo() - 1));
		// 現在のページ番号に対する終了レコード番号
		pagenationDTO.setEndRecordNo(pagenationDTO.getStartRecordNo() + (pageSize - 1));

		List<Integer> pageNumberList = new ArrayList<Integer>();
		for(int pageNumber = 1; pageNumber <= pagenationDTO.getTotalPageSize(); pageNumber++){
			pageNumberList.add(pageNumber);
		}

		List<ItemInfoDTO> productInfoPages = new ArrayList<ItemInfoDTO>();
		for(int pageNumberOffset = pagenationDTO.getStartRecordNo(); pageNumberOffset <= pagenationDTO.getEndRecordNo(); pageNumberOffset++){
			productInfoPages.add(list.get(pageNumberOffset));
		}
		pagenationDTO.setCurrentProductInfoPage(productInfoPages);

		if((pagenationDTO.getStartRecordNo() -1) <= 0){
			pagenationDTO.setPreviousPage(false);
		} else {
			pagenationDTO.setPreviousPage(true);
			pagenationDTO.setPreviousPageNo(pagenationDTO.getCurrentPageNo() - 1);
		}

		if(pagenationDTO.getEndRecordNo() + pageSize > pagenationDTO.getTotalRecordSize()){
			pagenationDTO.setNextPage(false);
		} else {
			pagenationDTO.setNextPage(true);
			pagenationDTO.setNextPageNo(pagenationDTO.getCurrentPageNo() + 1);
		}

		return pagenationDTO;
	}

}
