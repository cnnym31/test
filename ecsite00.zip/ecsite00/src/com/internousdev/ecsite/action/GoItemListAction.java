package com.internousdev.ecsite.action;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.internousdev.ecsite.dao.ItemInfoDAO;
import com.internousdev.ecsite.dto.ItemInfoDTO;
import com.opensymphony.xwork2.ActionSupport;

public class GoItemListAction extends ActionSupport {
	private List<ItemInfoDTO> itemList = new ArrayList<ItemInfoDTO>();

	public String execute() throws SQLException{
		ItemInfoDAO itemListDAO = new ItemInfoDAO();
		itemList = itemListDAO.getItemList();

		return SUCCESS;
	}

	public List<ItemInfoDTO> getItemList(){
		return itemList;
	}

	public void setItemList(List<ItemInfoDTO> itemList){
		this.itemList = itemList;
	}

}
