package com.internousdev.ecsite.action;

import java.sql.SQLException;

import com.internousdev.ecsite.dao.UserInfoDAO;
import com.opensymphony.xwork2.ActionSupport;

public class UserDeleteCompleteAction extends ActionSupport {

	private int id;

	public String execute() throws SQLException{
		UserInfoDAO userInfoDAO = new UserInfoDAO();
		userInfoDAO.userDelete(id);

		return SUCCESS;
	}

	public int getId(){
		return id;
	}

	public void setId(int id){
		this.id = id;
	}

}
