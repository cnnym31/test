package com.internousdev.ecsite.action;

import com.opensymphony.xwork2.ActionSupport;

public class GoLoginPageAction extends ActionSupport {
	public String execute(){
		return SUCCESS;
	}

}