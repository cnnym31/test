package com.internousdev.ecsite.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.internousdev.ecsite.dao.DestinationInfoDAO;
import com.internousdev.ecsite.dto.DestinationInfoDTO;
import com.opensymphony.xwork2.ActionSupport;

public class SettlementConfirmAction extends ActionSupport implements SessionAware {

	private Map<String, Object> session;

	public String execute(){
		DestinationInfoDAO destinationInfoDAO = new DestinationInfoDAO();
		List<DestinationInfoDTO> destinationInfoDTOList = new ArrayList<DestinationInfoDTO>();

		destinationInfoDTOList = destinationInfoDAO.getDestinationInfo(String.valueOf(session.get("loginId")));

		session.put("destinationInfoDTOList", destinationInfoDTOList);

		return SUCCESS;
	}

	@Override
	public void setSession(Map<String, Object> session){
		this.session = session;
	}

}

