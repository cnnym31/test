package com.internousdev.ecsite.action;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.internousdev.ecsite.dao.ItemInfoDAO;
import com.internousdev.ecsite.dto.ItemInfoDTO;
import com.opensymphony.xwork2.ActionSupport;

public class ItemDeleteAction extends ActionSupport implements SessionAware {
	private int id;
	public Map<String, Object> session;
	private List<ItemInfoDTO> itemList = new ArrayList<ItemInfoDTO>();

	public String execute() throws SQLException{
		ItemInfoDAO itemListDAO = new ItemInfoDAO();
		ItemInfoDTO itemListDTO = new ItemInfoDTO();

		itemListDTO = itemListDAO.getItemInfo(id);

		session.put("id", itemListDTO.getId());
		session.put("itemName", itemListDTO.getItemName());
		session.put("itemPrice", itemListDTO.getItemPrice());
		session.put("itemStock", itemListDTO.getItemStock());

		return SUCCESS;
	}

	public int getId(){
		return id;
	}

	public void setId(int id){
		this.id = id;
	}

	public List<ItemInfoDTO> getItemList(){
		return itemList;
	}

	public void setItemList(List<ItemInfoDTO> itemList){
		this.itemList = itemList;
	}

	public Map<String, Object> getSession(){
		return session;
	}

	public void setSession(Map<String, Object> session){
		this.session = session;
	}

}
