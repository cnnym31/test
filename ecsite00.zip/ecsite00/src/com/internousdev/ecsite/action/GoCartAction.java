package com.internousdev.ecsite.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.internousdev.ecsite.dao.CartInfoDAO;
import com.internousdev.ecsite.dto.CartInfoDTO;
import com.opensymphony.xwork2.ActionSupport;

public class GoCartAction extends ActionSupport implements SessionAware {

	private Map<String, Object> session;

	public String execute(){
		int userId = 0;

		userId = (int) session.get("user_id");

		CartInfoDAO cartInfoDAO = new CartInfoDAO();

		List<CartInfoDTO> cartInfoDTOList = new ArrayList<CartInfoDTO>();
		cartInfoDTOList = cartInfoDAO.getCartInfoDTOList(userId);
		session.put("cartInfoDTOList", cartInfoDTOList);

		return SUCCESS;
	}

	@Override
	public void setSession(Map<String, Object> session){
		this.session = session;
	}

}
