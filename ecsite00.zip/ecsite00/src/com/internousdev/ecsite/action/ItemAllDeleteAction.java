package com.internousdev.ecsite.action;

import java.sql.SQLException;

import com.internousdev.ecsite.dao.ItemInfoDAO;
import com.opensymphony.xwork2.ActionSupport;

public class ItemAllDeleteAction extends ActionSupport {
	public String execute() throws SQLException{
		ItemInfoDAO itemInfoDAO = new ItemInfoDAO();
		itemInfoDAO.itemAllDelete();

		return SUCCESS;
	}

}
