
public class Test {

	public static void main(String[] args) {
		Person taro = new Person("次郎", 18);//"次郎"18を記載するためには、コンストラクタ側(Person)にString/intの定義をする
		taro.name ="太郎";
		taro.age =20;
		System.out.println(taro.name);
		System.out.println(taro.age);

	}

}
