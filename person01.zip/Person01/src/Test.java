
public class Test {

	public static void main(String[] args){
		Person taro = new Person();
		taro.name = "山田太郎";
		taro.age = 20;
		taro.phoneNumber = "090-1111-1111";
		taro.address = "東京";
		taro.mail = "taro@xxx.jp";
		System.out.println(taro.name);
		System.out.println(taro.age);
		System.out.println(taro.phoneNumber);
		System.out.println(taro.address);
		System.out.println(taro.mail);
		taro.talk();
		taro.walk();
		taro.run();

		Person jiro = new Person();
		jiro.name = "木村次郎";
		jiro.age = 18;
		jiro.phoneNumber = "090-2222-2222";
		jiro.address = "大阪";
		jiro.mail = "jiro@xyz.jp";
		System.out.println(jiro.name);
		System.out.println(jiro.age);
		System.out.println(jiro.phoneNumber);
		System.out.println(jiro.address);
		System.out.println(jiro.mail);
		jiro.talk();
		jiro.walk();
		jiro.run();

		Person hanako = new Person();
		hanako.name = "鈴木花子";
		hanako.age = 16;
		hanako.phoneNumber = "090-3333-3333";
		hanako.address = "北海道";
		hanako.mail = "hanako@abc.jp";
		System.out.println(hanako.name);
		System.out.println(hanako.age);
		System.out.println(hanako.phoneNumber);
		System.out.println(hanako.address);
		System.out.println(hanako.mail);
		hanako.talk();
		hanako.walk();
		hanako.run();

		Person kurumi = new Person();
		kurumi.name = "尼野来美";
		kurumi.age = 26;
		kurumi.phoneNumber = "090-4444-4444";
		kurumi.address = "神奈川";
		kurumi.mail = "kurumi@aaa.jp";
		System.out.println(kurumi.name);
		System.out.println(kurumi.age);
		System.out.println(kurumi.phoneNumber);
		System.out.println(kurumi.address);
		System.out.println(kurumi.mail);
		kurumi.talk();
		kurumi.walk();
		kurumi.run();


		Robot aibo = new Robot();
		aibo.name = "aibo";
		System.out.println(aibo.name);
		aibo.talk();
		aibo.walk();
		aibo.run();

		Robot asimo = new Robot();
		asimo.name = "asimo";
		System.out.println(asimo.name);
		asimo.talk();
		asimo.walk();
		asimo.run();

		Robot pepper = new Robot();
		pepper.name = "pepper";
		System.out.println(pepper.name);
		pepper.talk();
		pepper.walk();
		pepper.run();

		Robot doraemon = new Robot();
		doraemon.name = "doraemon";
		System.out.println(doraemon.name);
		doraemon.talk();
		doraemon.walk();
		doraemon.run();



	}

}
