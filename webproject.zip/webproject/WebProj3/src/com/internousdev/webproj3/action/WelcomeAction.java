package com.internousdev.webproj3.action;

import com.opensymphony.xwork2.ActionSupport;

public class WelcomeAction extends ActionSupport {

	public String execute(){
		return SUCCESS;
	}

}
