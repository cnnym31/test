set names utf8;
set foreign_key_checks = 0;

drop database if exists sample;
create database if not exists sample;

use sample;

/* 会員情報テーブル */
create table user_info(
	id int primary key not null auto_increment,
	user_id varchar(16) unique not null,
	password varchar(16) not null,
	family_name varchar(32) not null,
	first_name varchar(32) not null,
	family_name_kana varchar(32) not null,
	first_name_kana varchar(32) not null,
	sex tinyint not null default 0, /* 0:男性 1:女性 */
	email varchar(32) not null,
	status tinyint not null default 0, /* 0:無効 1:有効 */
	logined tinyint not null default 0, /* 0:未ログイン 1:ログイン済 */
	regist_date datetime not null,
	update_date datetime not null
);

insert into user_info values
(1, "admin", "admin", "管理者", "管理者", "かんりしゃ", "かんりしゃ", 0, "admin@gmail.com", 0, 0, now(), now()),
(2, "guest", "guest", "ゲスト", "ユーザー", "げすと", "ゆーざー", 0, "guest@gmail.com", 0, 0, now(), now());


/* 商品情報テーブル */
create table product_info(
	id int primary key not null auto_increment,
	product_id int unique not null,
	product_name varchar(100) unique not null,
	product_name_kana varchar(100) unique not null,
	product_description varchar(255) not null,
	category_id int not null,
	price int,
	image_file_path varchar(100),
	image_file_name varchar(50),
	release_date datetime not null,
	release_company varchar(50),
	status tinyint not null default 0,  /* 0:無効 1:有効 */
	regist_date datetime not null,
	update_date datetime,
	foreign key(category_id) references m_category(category_id)
);

insert into product_info values
(1, 1, "test1", "てすと１", "test1の詳細", 2, 100, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(2, 2, "test2", "てすと２", "test2の詳細", 2, 200, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(3, 3, "test3", "てすと３", "test3の詳細", 2, 300, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(4, 4, "test4", "てすと４", "test4の詳細", 2, 400, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(5, 5, "test5", "てすと５", "test5の詳細", 2, 500, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(6, 6, "test6", "てすと６", "test6の詳細", 2, 600, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(7, 7, "test7", "てすと７", "test7の詳細", 2, 700, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(8, 8, "test8", "てすと８", "test8の詳細", 2, 800, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(9, 9, "test9", "てすと９", "test9の詳細", 2, 900, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(10, 10, "test10", "てすと１０", "test10の詳細", 2, 1000, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(11, 11, "test11", "てすと１１", "test11の詳細", 2, 1100, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(12, 12, "test12", "てすと１２", "test12の詳細", 2, 1200, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(13, 13, "test13", "てすと１３", "test13の詳細", 2, 1300, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(14, 14, "test14", "てすと１４", "test14の詳細", 2, 1400, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(15, 15, "test15", "てすと１５", "test15の詳細", 2, 1500, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(16, 16, "sample1", "さんぷる１", "sample1の詳細", 3, 100, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(17, 17, "sample2", "さんぷる２", "sample2の詳細", 3, 200, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(18, 18, "sample3", "さんぷる３", "sample3の詳細", 3, 300, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(19, 19, "sample4", "さんぷる４", "sample4の詳細", 3, 400, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(20, 20, "sample5", "さんぷる５", "sample5の詳細", 3, 500, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(21, 21, "sample6", "さんぷる６", "sample6の詳細", 3, 600, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(22, 22, "sample7", "さんぷる７", "sample7の詳細", 3, 700, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(23, 23, "sample8", "さんぷる８", "sample8の詳細", 3, 800, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(24, 24, "sample9", "さんぷる９", "sample9の詳細", 3, 900, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(25, 25, "sample10", "さんぷる１０", "sample10の詳細", 3, 1000, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(26, 26, "sample11", "さんぷる１１", "sample11の詳細", 3, 1100, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(27, 27, "sample12", "さんぷる１２", "sample12の詳細", 3, 1200, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(28, 28, "sample13", "さんぷる１３", "sample13の詳細", 3, 1300, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(29, 29, "sample14", "さんぷる１４", "sample14の詳細", 3, 1400, "./images", "test.png", now(), "発売会社", 0, now(), now()),
(30, 30, "sample15", "さんぷる１５", "sample15の詳細", 3, 1500, "./images", "test.png", now(), "発売会社", 0, now(), now());


/* カート情報テーブル */
create table cart_info(
	id int primary key not null auto_increment,
	user_id varchar(16) not null,
	temp_user_id varchar(16),
	product_id int not null,
	product_count int not null,
	price int not null,
	regist_date datetime not null,
	update_date datetime
);


/* 購入履歴情報テーブル */
create table purchase_history_info(
	id int primary key not null auto_increment,
	user_id varchar(16) not null,
	product_id int not null,
	product_count int not null,
	price int not null,
	destination_id int not null,
	regist_date datetime not null,
	update_date datetime not null,
	foreign key(product_id) references product_info(product_id)
);


/* 宛先情報テーブル */
create table destination_info(
	id int primary key not null auto_increment,
	user_id varchar(16) not null,
	family_name varchar(32) not null,
	first_name varchar(32) not null,
	famnily_name_kana varchar(32) not null,
	first_name_kana varchar(32) not null,
	email varchar(32) not null,
	tel_number varchar(13) not null,
	user_address varchar(50) not null,
	regist_date datetime not null,
	update_date datetime not null
);

insert into destination_info values
(1, "guest", "ゲスト", "ユーザー" , "げすと", "ゆーざー" , "guest@gmail.com", "012-345-6789", "東京都○○○区" , now(), "0000-00-00 00:00:00");


/* カテゴリーマスターテーブル */
create table m_category(
	id int primary key not null,
	category_id int not null unique,
	category_name varchar(20) not null unique,
	category_description varchar(100),
	insert_date datetime not null,
	update_date datetime
);

insert into m_category values
(1, 1, "全てのカテゴリー", "テスト・サンプル全てのカテゴリーが対象となります", now(), null),
(2, 2, "テスト", "テストに関するカテゴリーが対象となります", now(), null),
(3, 3, "サンプル", "サンプルに関するカテゴリーが対象となります", now(), null);
