package com.internousdev.sample.action;

import com.opensymphony.xwork2.ActionSupport;

public class GoLoginAction extends ActionSupport {

	public String execute(){
		return SUCCESS;
	}

}
