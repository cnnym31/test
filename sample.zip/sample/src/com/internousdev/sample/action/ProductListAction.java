package com.internousdev.sample.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.internousdev.sample.dao.MCategoryDAO;
import com.internousdev.sample.dao.ProductInfoDAO;
import com.internousdev.sample.dto.MCategoryDTO;
import com.internousdev.sample.dto.PagenationDTO;
import com.internousdev.sample.dto.ProductInfoDTO;
import com.internousdev.sample.util.Pagenation;
import com.opensymphony.xwork2.ActionSupport;

public class ProductListAction extends ActionSupport implements SessionAware {

	private String productName;
	private String productNameKana;
	private String imageFilePath;
	private String imageFileName;
	private int price;

	private String categoryId;
	private String keywords;
	private List<MCategoryDTO> mCategoryDTOList = new ArrayList<MCategoryDTO>();
	private List<ProductInfoDTO> productInfoDTOList = new ArrayList<ProductInfoDTO>();
	private Map<String, Object> session;

	public String execute(){
		String result = ERROR;

		ProductInfoDAO productInfoDAO = new ProductInfoDAO();
		productInfoDTOList = productInfoDAO.selectAll();
		Pagenation pagenation = new Pagenation();
		PagenationDTO pagenationDTO = pagenation.initialize(productInfoDTOList, 9);

		session.put("totalPageSize", pagenationDTO.getTotalPageSize());
		session.put("currentPageNumber", pagenationDTO.getCurrentPageNo());
		session.put("totalRecordSize", pagenationDTO.getTotalPageSize());
		session.put("startRecordNo", pagenationDTO.getStartRecordNo());
		session.put("endRecordSize", pagenationDTO.getEndRecordNo());
		session.put("pageNumbaeList", pagenationDTO.getPageNumberList());
		session.put("productInfoDTOList", pagenationDTO.getCurrentProductInfoPage());
		session.put("hasNextPage", pagenationDTO.hasNextPage());
		session.put("hasPreviousPage", pagenationDTO.hasPreviousPage());
		session.put("nextPageNp", pagenationDTO.getNextPageNo());
		session.put("previousPageNo", pagenationDTO.getPreviousPageNo());

		if(!session.containsKey("mCategoryList")){
			MCategoryDAO mCategoryDAO = new MCategoryDAO();
			mCategoryDTOList = mCategoryDAO.selectAll();
			session.put("mCategoryDTOList", mCategoryDTOList);
		}

		result = SUCCESS;
		return result;
	}

	public String getProductName(){
		return productName;
	}

	public void setProductName(String productName){
		this.productName = productName;
	}

	public String getProductNameKana(){
		return productNameKana;
	}

	public void setProductNameKana(String productNameKana){
		this.productNameKana = productNameKana;
	}

	public String getImageFilePath(){
		return imageFilePath;
	}

	public void setImageFilePath(String imageFilePath){
		this.imageFilePath = imageFilePath;
	}

	public String getImageFileName(){
		return imageFileName;
	}

	public void setImageFileName(String imageFileName){
		this.imageFileName = imageFileName;
	}

	public int getPrice(){
		return price;
	}

	public void setPrice(int price){
		this.price = price;
	}

	public String getCategoryId(){
		return categoryId;
	}

	public void seetCategoryId(String categoryId){
		this.categoryId = categoryId;
	}

	public String getKeywords(){
		return keywords;
	}

	public void setKeywords(String keywords){
		this.keywords = keywords;
	}

	public List<MCategoryDTO> getMCategoryDTOList(){
		return mCategoryDTOList;
	}

	public void setMCategoryDTOList(List<MCategoryDTO> mCategoryDTOList){
		this.mCategoryDTOList = mCategoryDTOList;
	}

	public List<ProductInfoDTO> getProductInfoDTOList(){
		return productInfoDTOList;
	}

	public void setProductInfoDTOList(List<ProductInfoDTO> productInfoDTOList){
		this.productInfoDTOList = productInfoDTOList;
	}

	@Override
	public void setSession(Map<String, Object> session){
		this.session = session;
	}

}
