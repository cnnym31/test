package com.internousdev.sample.action;

import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.internousdev.sample.dao.UserInfoDAO;
import com.internousdev.sample.dto.UserInfoDTO;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport implements SessionAware {

	private String userId;
	private String password;
	private Map<String, Object> session;

	public String execute(){
		UserInfoDAO userInfoDAO = new UserInfoDAO();
		UserInfoDTO userInfoDTO = new UserInfoDTO();

		String result = ERROR;
		userInfoDTO = userInfoDAO.select(userId, password);
		session.put("loginUser", userInfoDTO);

		if(userId.equals(userInfoDTO.getUserId()) && password.equals(userInfoDTO.getPassword())){
				result = SUCCESS;
				session.put("loginId", userInfoDTO.getId());
				session.put("logined", 1);
			}

		return result;
	}

	public String getUserId(){
		return userId;
	}

	public void setUserId(String userId){
		this.userId = userId;
	}

	public String getPassword(){
		return password;
	}

	public void setPassword(String password){
		this.password = password;
	}

	@Override
	public void setSession(Map<String, Object> session){
		this.session = session;
	}

}
