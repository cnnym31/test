package com.internousdev.sample.util;

import java.util.ArrayList;
import java.util.List;

import com.internousdev.sample.dto.PagenationDTO;
import com.internousdev.sample.dto.ProductInfoDTO;

public class Pagenation {

	public PagenationDTO initialize(List<ProductInfoDTO> list, int pageSize){

		PagenationDTO pagenationDTO = new PagenationDTO();

		// 全ページ数
		pagenationDTO.setTotalPageSize((int)(Math.ceil(list.size() / pageSize)));
		// 現在のページ番号
		pagenationDTO.setCurrentPageNo(1);
		// 全レコード数
		pagenationDTO.setTotalRecordSize(list.size() - 1);
		// 現在のページ番号に対する開始レコード番号（オフセット）
		pagenationDTO.setStartRecordNo(pageSize * (pagenationDTO.getCurrentPageNo() - 1));
		// 現在のページ番号に対する終了レコード番号
		pagenationDTO.setEndRecordNo(pagenationDTO.getStartRecordNo() + (pageSize - 1));

		List<Integer> pageNumberList = new ArrayList<Integer>();
		for(int pageNumber = 1; pageNumber <= pagenationDTO.getTotalPageSize(); pageNumber++){
			pageNumberList.add(pageNumber);
		}

		List<ProductInfoDTO> productInfoPages = new ArrayList<ProductInfoDTO>();
		for(int pageNumberOffset = pagenationDTO.getStartRecordNo(); pageNumberOffset <= pagenationDTO.getEndRecordNo(); pageNumberOffset++){
			productInfoPages.add(list.get(pageNumberOffset));
		}
		pagenationDTO.setCurrentProductInfoPage(productInfoPages);

		if((pagenationDTO.getStartRecordNo() -1) <= 0){
			pagenationDTO.setPreviousPage(false);
		} else {
			pagenationDTO.setPreviousPage(true);
			pagenationDTO.setPreviousPageNo(pagenationDTO.getCurrentPageNo() - 1);
		}

		if(pagenationDTO.getEndRecordNo() + pageSize > pagenationDTO.getTotalRecordSize()){
			pagenationDTO.setNextPage(false);
		} else {
			pagenationDTO.setNextPage(true);
			pagenationDTO.setNextPageNo(pagenationDTO.getCurrentPageNo() + 1);
		}

		return pagenationDTO;
	}

	public PagenationDTO getPage(List<ProductInfoDTO> list, int pageSize, String pageNo){

		PagenationDTO pagenationDTO = new PagenationDTO();

		// 全ページ数
		pagenationDTO.setTotalPageSize((int)(Math.ceil(list.size() / pageSize)));
		// 現在のページ番号
		pagenationDTO.setCurrentPageNo(1);
		// 全レコード数
		pagenationDTO.setTotalRecordSize(list.size() - 1);
		// 現在のページ番号に対する開始レコード番号（オフセット）
		pagenationDTO.setStartRecordNo(pageSize * (pagenationDTO.getCurrentPageNo() - 1));
		// 現在のページ番号に対する終了レコード番号
		pagenationDTO.setEndRecordNo(pagenationDTO.getStartRecordNo() + (pageSize - 1));

		List<Integer> pageNumberList = new ArrayList<Integer>();
		for(int pageNumber = 1; pageNumber <= pagenationDTO.getTotalPageSize(); pageNumber++){
			pageNumberList.add(pageNumber);
		}

		List<ProductInfoDTO> productInfoPages = new ArrayList<ProductInfoDTO>();
		for(int pageNumberOffset = pagenationDTO.getStartRecordNo(); pageNumberOffset <= pagenationDTO.getEndRecordNo(); pageNumberOffset++){
			productInfoPages.add(list.get(pageNumberOffset));
		}
		pagenationDTO.setCurrentProductInfoPage(productInfoPages);

		if((pagenationDTO.getStartRecordNo() -1) <= 0){
			pagenationDTO.setPreviousPage(false);
		} else {
			pagenationDTO.setPreviousPage(true);
			pagenationDTO.setPreviousPageNo(pagenationDTO.getCurrentPageNo() - 1);
		}

		if(pagenationDTO.getEndRecordNo() + pageSize > pagenationDTO.getTotalRecordSize()){
			pagenationDTO.setNextPage(false);
		} else {
			pagenationDTO.setNextPage(true);
			pagenationDTO.setNextPageNo(pagenationDTO.getCurrentPageNo() + 1);
		}

		return pagenationDTO;
	}

}
