package com.internousdev.sample.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.internousdev.sample.dto.CartInfoDTO;
import com.internousdev.sample.util.DBConnector;


public class CartInfoDAO {

	public List<CartInfoDTO> cartInfoDTOList(int userId){
		DBConnector dbConnector = new DBConnector();
		Connection connection = dbConnector.getConnection();
		List<CartInfoDTO> cartInfoDTOList = new ArrayList<CartInfoDTO>();

		String sql = "SELECT ci.id, ci.user_id, ci.temp_user_id, ci.product_id,"
				+ " ci.product_count, pi.price, pi.regist_date, pi.update_date,"
				+ " pi.product_name, pi.product_name_kana, pi.product_description,"
				+ " pi.category_id, pi.image_file_path, pi.image_file_name,"
				+ " pi.release_date, pi.release_company, pi.status,"
				+ " ci.product_count * pi.price as subtotal"
				+ " FROM cart_info ci LEFT JOIN product_info pi"
				+ " ON ci.product_id = pi.product_id"
				+ " WHERE ci.user_id=? GROUP BY product_id";

		try{
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, userId);
			ResultSet resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
				CartInfoDTO cartInfoDTO = new CartInfoDTO();
				cartInfoDTO.setId(resultSet.getInt("id"));
				cartInfoDTO.setUserId(resultSet.getString("user_id"));
				cartInfoDTO.setTempUserId(resultSet.getString("temp_user_id"));
				cartInfoDTO.setProductId(resultSet.getInt("product_id"));
				cartInfoDTO.setProductCount(resultSet.getInt("product_count"));
				cartInfoDTO.setPrice(resultSet.getInt("price"));
				cartInfoDTO.setRegistDate(resultSet.getDate("regist_date"));
				cartInfoDTO.setUpdateDate(resultSet.getDate("update_date"));
				cartInfoDTO.setProductName(resultSet.getString("product_name"));
				cartInfoDTO.setProductNameKana(resultSet.getString("product_name_kana"));
				cartInfoDTO.setProductDescription(resultSet.getString("product_description"));
				cartInfoDTO.setCategoryId(resultSet.getInt("category_id"));
				cartInfoDTO.setImageFilePath(resultSet.getString("image_file_path"));
				cartInfoDTO.setImageFileName(resultSet.getString("image_file_name"));
				cartInfoDTO.setReleaseDate(resultSet.getDate("release_date"));
				cartInfoDTO.setReleaseCompany(resultSet.getString("release_company"));
				cartInfoDTO.setStatus(resultSet.getString("status"));
				cartInfoDTO.setSubtotal(resultSet.getInt("subtotal"));
				cartInfoDTOList.add(cartInfoDTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cartInfoDTOList;
	}

	public int addCart(int userId, String tempUserId, int productId, String productCount, int price){
		DBConnector dbConnector = new DBConnector();
		Connection connection = dbConnector.getConnection();

		String sql = "INSERT INTO cart_info(user_id, temp_user_id, product_id, product_count, price, regist_date)"
				+ " VALUES(?, ?, ?, ?, ?, now())";

		int count = 0;

		try {
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, userId);
			preparedStatement.setString(2, tempUserId);
			preparedStatement.setInt(3, productId);
			preparedStatement.setString(4, productCount);
			preparedStatement.setInt(5, price);
			count = preparedStatement.executeUpdate();
		} catch (SQLException e){
			e.printStackTrace();
		}

		try{
			connection.close();
		} catch (SQLException e){
			e.printStackTrace();
		}

		return count;
	}

	public int totalPrice(int userId){
		DBConnector dbConnector = new DBConnector();
		Connection connection = dbConnector.getConnection();

		String sql = "SELECT product_count * price as total_price FROM cart_info WHERE user_id=? GROUP BY user_id";

		int totalPrice = 0;

		try{
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, userId);
			ResultSet resultSet = preparedStatement.executeQuery();

			if(resultSet.next()){
				totalPrice = resultSet.getInt("total_price");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return totalPrice;
	}

}
