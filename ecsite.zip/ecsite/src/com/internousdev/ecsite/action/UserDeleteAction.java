package com.internousdev.ecsite.action;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.internousdev.ecsite.dao.UserSelectDAO;
import com.internousdev.ecsite.dto.UserListDTO;
import com.opensymphony.xwork2.ActionSupport;

public class UserDeleteAction extends ActionSupport implements SessionAware {
	public Map<String, Object> session;
	private List<UserListDTO> userList = new ArrayList<UserListDTO>();

	public String execute() throws SQLException{
		UserSelectDAO userSelectDAO = new UserSelectDAO();
		UserListDTO userListDTO = new UserListDTO();

		session.put("id", userListDTO.getId());

		userList = userSelectDAO.getSelectUserList(3);

		return SUCCESS;
	}

	public List<UserListDTO> getUserList(){
		return userList;
	}

	public void setUserList(List<UserListDTO> userList){
		this.userList = userList;
	}

	public Map<String, Object> getSession(){
		return session;
	}

	@Override
	public void setSession(Map<String, Object> session){
		this.session = session;
	}

}
