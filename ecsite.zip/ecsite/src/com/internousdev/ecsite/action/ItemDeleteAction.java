package com.internousdev.ecsite.action;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.SessionAware;

import com.internousdev.ecsite.dao.ItemSelectDAO;
import com.internousdev.ecsite.dto.ItemListDTO;
import com.opensymphony.xwork2.ActionSupport;


public class ItemDeleteAction extends ActionSupport implements SessionAware {

	public Map<String, Object> session;
	private List<ItemListDTO> itemList = new ArrayList<ItemListDTO>();

	public String execute() throws SQLException{
		ItemSelectDAO itemSelectDAO = new ItemSelectDAO();
		//test
		System.out.println(itemSelectDAO);

		ItemListDTO itemListDTO = new ItemListDTO();
		//test
		System.out.println(itemListDTO);

		session.put("id", itemListDTO.getId());
		//test
		System.out.println(itemListDTO.getId());
		System.out.println(session.get("id"));

		int intId = Integer.parseInt(session.get("id").toString());
		//test
		System.out.println(intId);

		itemList = itemSelectDAO.getSelectItemList(intId);

		return SUCCESS;

	}


	public List<ItemListDTO> getItemList(){
		return itemList;
	}

	public void setItemList(List<ItemListDTO> itemList){
		this.itemList = itemList;
	}

	public Map<String, Object> getSession(){
		return session;
	}

	@Override
	public void setSession(Map<String, Object> session){
		this.session = session;
	}
}
