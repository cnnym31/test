package com.internousdev.ecsite.action;

import com.opensymphony.xwork2.ActionSupport;

public class UserUpdateConfirmAction extends ActionSupport {

	public String execute(){
		return SUCCESS;
	}

}
